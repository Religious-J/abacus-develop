//==========================================================
// AUTHOR : Peize Lin
// DATE : 2016-01-24
//==========================================================

#ifndef CENTER2_ORB_H
#define CENTER2_ORB_H

class Center2_Orb
{
public:
	class Orb11;
	class Orb21;
	class Orb22;
};

#endif //CENTER2_ORB_H